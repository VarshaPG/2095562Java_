package com.rays.dao;

import java.util.List;

public interface AssociatesDao {
	
	public int addAssociates(Associates associates);
	public List<Associates> getAllAssociates();
	public Associates getAssociatesById(int id);
	public int updateAssociates(int associates1);
	public int deleteAssociates(int id);

}

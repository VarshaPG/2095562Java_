
public class StringMethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="Jonathaon";
		System.out.println("name:" +name);
		System.out.println("3rd character of name:" + name.charAt(2));
		System.out.println("Jonathon compared to Solomon:" + name.compareTo("Solomon"));
		System.out.println("Is Jonathon equal to Jonathon? " + name.equals("Jonathon"));
		System.out.println("Length of name:" + name.length());
		System.out.println("Replace a's with e's in name: " + name.replace('a', 'e'));
		int index=name.indexOf('a');
		System.out.println(index);
		String t= name.substring(2 ,8);
		System.out.println(t);
}

}

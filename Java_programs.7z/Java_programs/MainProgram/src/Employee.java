
public class Employee {
	long empId=345;
	double empSalary=2325.50;
	float empTax=9.5f;
	int daysOfWork=24;
	void calculatePF(){
	float pfRate=10.5f;
	System.out.println("The PF Rate of the Employee is =" +pfRate);
}
}

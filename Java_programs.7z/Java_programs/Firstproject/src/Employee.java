
public class Employee {
		
		int id;
		String name;
		double salary;
		int age;
        void displayEmp(){
			System.out.println("EmployeeID:"+id);
			System.out.println("EmployeeName:"+name);
			System.out.println("EmployeeSalary:"+salary);
			System.out.println("EmployeeAGE:"+age);}
		} 


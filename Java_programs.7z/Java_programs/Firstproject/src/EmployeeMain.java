
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Employee employee=new Employee();
        employee.id=101;
        employee.name="virat";
        employee.salary=25000;
        employee.age=25;
        employee.displayEmp();
	}

}

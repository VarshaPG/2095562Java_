
public class AbstractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s=new Circle();
		Shape sq=new Square();
		s.CalculateArea();
		s.SetColor();
		sq.CalculateArea();
		sq.SetColor();
		

	}

}

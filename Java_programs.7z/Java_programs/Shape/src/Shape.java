
public abstract class Shape {
	public abstract void CalculateArea();
	public abstract void SetColor();
		
	}

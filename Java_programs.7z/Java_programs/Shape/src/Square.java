
public class Square extends Shape {
	public void CalculateArea() {
		int len=4;
		int bre=4;
		double Sarea=len*bre;
		System.out.println("Area of Square"+Sarea);
	}
	
	public void SetColor(){
	
	System.out.println("White");
}}


public class Circle extends Shape {
	 public void CalculateArea() {
		 int r=5;
		 double Carea=3.14*r*r;
		 System.out.println("Area of circle is"+Carea);
	}
	public void SetColor(){
		
	System.out.println("RED");
	
	}
}

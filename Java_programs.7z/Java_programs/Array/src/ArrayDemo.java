
public class ArrayDemo {
	int[] numbers;

	public void StoreNumbers() {
	numbers = new int[101];
	for (int i=0;i<=100;i++){
	numbers[i]= i;
	}
	}



	public void PrintEvenNumber(){
	System.out.println("The even numbers between 0 and 100 are");

	for (int i=0;i<numbers.length;i++){
	if((numbers[i] % 2)==0){
	System.out.println(numbers[i]);
	}
}
}
}
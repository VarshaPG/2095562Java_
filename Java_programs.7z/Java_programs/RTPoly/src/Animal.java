
public class Animal {
	void whoAmI(){
		System.out.println("I m a generic Animal.");

	}

}

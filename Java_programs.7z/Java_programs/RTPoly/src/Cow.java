class Cow extends Animal {
	void whoAmI(){
		System.out.println("I m a Cow.");

	}

}


public class RTPoly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal ref1=new Animal();
		Animal ref2=new Dog();
		Animal ref3=new Cow();
		ref1.whoAmI();
		ref2.whoAmI();
		ref3.whoAmI();
	}

}

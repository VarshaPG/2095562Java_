
public class Car extends MotorisedVehicle {
	public interface MotorisedVehicle extends IVehicle {
		public default void drive(){
			System.out.println("Is in good Condition");
		}
		
}

	public static void drive() {
		// TODO Auto-generated method stub
		System.out.println("Is in good Condition");
	}


}

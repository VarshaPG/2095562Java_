
public class InterfaceDemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car i=new Car();
		Car.drive();
	}

}

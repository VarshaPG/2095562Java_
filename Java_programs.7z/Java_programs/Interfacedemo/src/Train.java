
public abstract class Train implements IVehicle,IPublicTransport {
	public void turnLeft(){
		System.out.println("Turn Left Side");
	}
	public void brake(){
		System.out.println("Apply Brake");
	}
}

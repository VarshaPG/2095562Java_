
public class MotorisedVehicle {
	public void CheckMotor() {
	}
	{
		System.out.println("The Motor of Vehicle is in good condition");
	}

}

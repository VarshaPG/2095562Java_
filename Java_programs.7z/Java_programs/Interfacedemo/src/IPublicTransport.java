
public interface IPublicTransport {
	public int getNumberofPeople();
}
